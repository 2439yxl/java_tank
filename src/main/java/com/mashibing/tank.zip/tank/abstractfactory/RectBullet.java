package com.mashibing.tank.abstractfactory;

import com.mashibing.tank.*;

import java.awt.*;

public class RectBullet extends BaseBullet {

    private static final float BULLET_SPEED = 20;
    public static int WIDTH = ResourceMgr.bulletD.getWidth();
    public static int HEIGHT = ResourceMgr.bulletD.getHeight();
    private GameModel model;

    private Rectangle rect = new Rectangle(0, 0, WIDTH, HEIGHT);
    private int x, y;
    private Dir dir;
    private boolean living = true;
    private Group group;

    // model 字段由 BaseBullet 提供（protected GameModel model;）
    public RectBullet(int x, int y, Dir dir, Group group, GameModel model) {
        this.x = x;
        this.y = y;
        this.dir = dir;
        this.group = group;
        this.model = model;
        rect.x = this.x;
        rect.y = this.y;
        rect.width = this.WIDTH;
        rect.height = this.HEIGHT;
        model.bullets.add(this);
    }

    public boolean isLiving() {
        return living;
    }

    /** 只负责绘制，不做任何状态变更。 */
    @Override
    public void paint(Graphics g) {
        if (!living) return;
        Color c = g.getColor();
        g.setColor(Color.YELLOW);
        g.fillRect(x, y, 20, 20);
        g.setColor(c);
    }

    @Override
    public int getWidth() {
        return 0;
    }

    @Override
    public int getHeight() {
        return 0;
    }

    /** 由 GameModel.update() 显式调用。 */
    public void move() {
        if (!living) return;
        switch (dir) {
            case LEFT:  x -= BULLET_SPEED; break;
            case RIGHT: x += BULLET_SPEED; break;
            case UP:    y -= BULLET_SPEED; break;
            case DOWN:  y += BULLET_SPEED; break;
        }
        rect.x = this.x;
        rect.y = this.y;

        if (x < 0 || y < 0 || x > TankFrame.GAME_WIDTH - 1 || y > TankFrame.GAME_HEIGHT - 1) {
            living = false;
        }
    }

    @Override
    public void collideWith(Tank tank) {
        if (!living) return ;
        if (this.group == tank.getGroup()) return ;
        if (rect.intersects(tank.rect)) {
            tank.die();
            this.die();
            int eX = tank.getX() + Tank.WIDTH / 2 - Explode.WIDTH / 2;
            int eY = tank.getY() + Tank.HEIGHT / 2 - Explode.HEIGHT / 2;
            model.add(new Explode(eX, eY, model));
        }
    }

    private void die() {
        this.living = false;
    }
}